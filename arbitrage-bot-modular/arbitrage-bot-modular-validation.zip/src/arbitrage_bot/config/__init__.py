"""Configuration loading and selection."""
