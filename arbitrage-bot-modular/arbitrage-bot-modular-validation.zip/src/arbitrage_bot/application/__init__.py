"""Application composition and lifecycle."""
