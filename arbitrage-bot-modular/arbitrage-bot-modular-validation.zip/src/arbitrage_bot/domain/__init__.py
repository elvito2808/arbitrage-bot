"""Provider-neutral value objects."""
